window.twttr = window.twttr || {};
window.twttr.anywhere = function () {
  var messages = [
    "@Anywhere has been retired, and support discontinued.",
    "For more information see https://dev.twitter.com/blog/sunsetting-anywhere",
    "For alternative Twitter tools such as Tweet and Follow buttons, and Web Intents, see https://dev.twitter.com/docs/twitter-for-websites"
  ];
  for (var i = 0, m; m = messages[i]; i++) {
    if (window.console) {
      if (console.warn) console.warn(m);
      else console.log(m);
    }
  }
};